DropMag Android (AML)

Struktur:
  jni/main.cpp, Android.mk, Application.mk   -> source plugin (build dengan NDK: ndk-build)
  files/DropMag/DropMag.ini                  -> konfigurasi (isi ID model)
  files/DropMag/audio/magdrop1-3.mp3         -> suara mp3 asli (magdrop1.mp3 - magdrop3.mp3)
  files/DropMag/models/*.dff                 -> DFF magazen milikmu (belum didaftarkan sebagai model)

Build:
  1. Taruh folder "mod/" dari repo AML (amlmod.h, logger.h) di dalam jni/
  2. ndk-build  -> libs/arm64-v8a/libDropMag.so (64-bit) dan libs/armeabi-v7a/libDropMag.so (32-bit)
  3. Pakai .so yang sesuai arsitektur game (arm64-v8a untuk game 64-bit) dan salin ke folder mod AML (mis. Android/data/<paket game>/mods/)
  4. Salin folder files/DropMag ke <folder config AML>/DropMag/

Catatan DFF:
  Plugin memuat DFF langsung dari files/DropMag/models/ dengan nama file apa adanya.
  Tidak perlu rename atau import ke IMG/IDE. Isi ModelXXX di INI hanya jika kamu
  ingin memakai model yang sudah terdaftar sendiri.

File log:
  Saat game jalan, plugin menulis DropMag.log di folder DropMag yang dipakai
  (kalau gagal, di /storage/emulated/0/Download/DropMag.log).
  Isinya: folder yang ditemukan, DFF yang berhasil dimuat, reload yang terdeteksi.
