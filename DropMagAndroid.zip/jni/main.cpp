// DropMag (Android) - magazen jatuh saat reload, dengan suara.
// Target: GTA SA Android, dimuat lewat AML (Android Mod Loader).
//   - arm64-v8a  (64-bit, mis. GTA SA 2.10)  <- build utama
//   - armeabi-v7a (32-bit, mis. GTA SA 2.00) tetap didukung lewat #if di bawah
// Kode orisinal. BELUM DIUJI di perangkat: semua symbol dicek null, kalau ada yang
// tidak ditemukan plugin menonaktifkan diri dan menulis alasannya ke logcat (tag: DropMag).
#include <mod/amlmod.h>
#include <mod/logger.h>
#include <SLES/OpenSLES.h>
#include <SLES/OpenSLES_Android.h>
#include <stdio.h>
#include <stdarg.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <vector>
#include <string>

MYMOD(net.dropmag.plugin, DropMag, 1.0, DropMag)
BEGIN_DEPLIST()
    ADD_DEPENDENCY_VER(net.rusjj.aml, 1.0.2.1)
END_DEPLIST()

struct V3 { float x, y, z; };

// ---------------------------------------------------------------- konfigurasi
struct Config {
    int   modelFor[48];          // indeks = eWeaponType, 0 = nonaktif
    int   spawnDelayMs = 700;
    int   lifetimeMs   = 30000;
    int   maxMags      = 20;
    float groundOffset = 0.03f;
    float gravity      = 30.0f;  // m/s^2 (efek jatuh dibuat plugin sendiri)
    float volume       = 1.0f;
    int   donorModel   = 1212;   // model objek kecil yang sudah ada di game, dipinjam sebagai 'wadah' DFF
    int   useDff       = 1;      // 1 = muat DFF dari folder models/
    Config() { memset(modelFor, 0, sizeof(modelFor)); }
} cfg;

enum { W_PISTOL = 22, W_SILENCED = 23, W_DEAGLE = 24, W_UZI = 28, W_MP5 = 29,
       W_AK47 = 30, W_M4 = 31, W_TEC9 = 32 };

static std::string g_dir;   // folder data plugin

// ---------------------------------------------------------------- log (logcat + file DropMag.log)
static std::string g_logPath;
static std::string g_logBuf;    // pesan yang muncul sebelum lokasi log diketahui
static bool        g_logOff = false;
static void WriteLogLine(const char* tag, const char* msg) {
    if (g_logOff) return;
    char line[700];
    snprintf(line, sizeof(line), "[%s] %s\n", tag, msg);
    if (g_logPath.empty()) { g_logBuf += line; return; }
    FILE* f = fopen(g_logPath.c_str(), "a");
    if (f) { fputs(line, f); fclose(f); }
}
static void LogI(const char* fmt, ...) {
    char b[600]; va_list a; va_start(a, fmt); vsnprintf(b, sizeof(b), fmt, a); va_end(a);
    logger->Info("%s", b); WriteLogLine("I", b);
}
static void LogE(const char* fmt, ...) {
    char b[600]; va_list a; va_start(a, fmt); vsnprintf(b, sizeof(b), fmt, a); va_end(a);
    logger->Error("%s", b); WriteLogLine("E", b);
}
static void StartLogFile(const std::string& dir) {
    mkdir(dir.c_str(), 0777);   // error diabaikan bila folder sudah ada
    std::string p = dir + "/DropMag.log";
    FILE* f = fopen(p.c_str(), "w");
    if (!f) { p = "/storage/emulated/0/Download/DropMag.log"; f = fopen(p.c_str(), "w"); }
    if (!f) { g_logOff = true; g_logBuf.clear(); logger->Error("DropMag: tidak bisa menulis file log"); return; }
    fputs("DropMag log (build: DFF otomatis + mp3, 64-bit)\n", f);
    fputs(g_logBuf.c_str(), f);
    fclose(f);
    g_logBuf.clear();
    g_logPath = p;
    logger->Info("DropMag: file log = %s", p.c_str());
    WriteLogLine("I", ("file log = " + p).c_str());
}

static bool FileExists(const std::string& p) { FILE* f = fopen(p.c_str(), "rb"); if (f) { fclose(f); return true; } return false; }
static std::string FindDir() {
    std::vector<std::string> c;
    c.push_back(std::string(aml->GetConfigPath()) + "/DropMag");
    const char* roots[] = { "/storage/emulated/0/Android_unprotected/data/com.rockstargames.gtasa",
                            "/storage/emulated/0/Android/data/com.rockstargames.gtasa" };
    for (const char* r : roots) {
        c.push_back(std::string(r) + "/files/DropMag");
        c.push_back(std::string(r) + "/files/configs/DropMag");
        c.push_back(std::string(r) + "/configs/DropMag");
        c.push_back(std::string(r) + "/mods/DropMag");
    }
    for (auto& d : c) {
        if (FileExists(d + "/DropMag.ini") || FileExists(d + "/audio/magdrop1.mp3")) {
            LogI("DropMag: folder data ditemukan: %s", d.c_str());
            return d;
        }
        LogI("DropMag: dicek, tidak ada: %s", d.c_str());
    }
    LogE("DropMag: folder DropMag tidak ketemu di mana pun, pakai %s", c[0].c_str());
    return c[0];
}

static void LoadConfig() {
    std::string path = g_dir + "/DropMag.ini";
    FILE* f = fopen(path.c_str(), "r");
    if (!f) { LogE("DropMag: %s tidak ditemukan, pakai default (semua senjata nonaktif)", path.c_str()); return; }
    char line[256];
    while (fgets(line, sizeof(line), f)) {
        if (line[0] == ';' || line[0] == '[' || line[0] == '#') continue;
        char* eq = strchr(line, '=');
        if (!eq) continue;
        *eq = 0;
        const char* k = line;
        float v = (float)atof(eq + 1);
        if      (!strcmp(k, "ModelPistol"))   cfg.modelFor[W_PISTOL]   = (int)v;
        else if (!strcmp(k, "ModelSilenced")) cfg.modelFor[W_SILENCED] = (int)v;
        else if (!strcmp(k, "ModelDeagle"))   cfg.modelFor[W_DEAGLE]   = (int)v;
        else if (!strcmp(k, "ModelUzi"))      cfg.modelFor[W_UZI]      = (int)v;
        else if (!strcmp(k, "ModelMP5"))      cfg.modelFor[W_MP5]      = (int)v;
        else if (!strcmp(k, "ModelAK47"))     cfg.modelFor[W_AK47]     = (int)v;
        else if (!strcmp(k, "ModelM4"))       cfg.modelFor[W_M4]       = (int)v;
        else if (!strcmp(k, "ModelTec9"))     cfg.modelFor[W_TEC9]     = (int)v;
        else if (!strcmp(k, "SpawnDelayMs"))  cfg.spawnDelayMs = (int)v;
        else if (!strcmp(k, "LifetimeMs"))    cfg.lifetimeMs   = (int)v;
        else if (!strcmp(k, "MaxMags"))       cfg.maxMags      = (int)v;
        else if (!strcmp(k, "GroundOffset"))  cfg.groundOffset = v;
        else if (!strcmp(k, "Gravity"))       cfg.gravity      = v;
        else if (!strcmp(k, "Volume"))        cfg.volume       = v;
        else if (!strcmp(k, "DonorModel"))    cfg.donorModel   = (int)v;
        else if (!strcmp(k, "UseDff"))        cfg.useDff       = (int)v;
    }
    fclose(f);
}

// ---------------------------------------------------------------- suara (OpenSL ES)
struct Sound {
    int fd = -1;                 // fd file mp3 (harus tetap terbuka selama player hidup)
    SLObjectItf playerObj = nullptr;
    SLPlayItf   play = nullptr;
    SLSeekItf   seek = nullptr;
};
static SLObjectItf g_engineObj = nullptr, g_mixObj = nullptr;
static SLEngineItf g_engine = nullptr;
static Sound g_sounds[3];
static int   g_soundCount = 0;
static bool  g_soundTried = false;

// Memutar mp3 lewat decoder bawaan Android (OpenSL ES, sumber = file descriptor)
static bool InitSound() {
    LogI("DropMag: init suara, folder = %s", g_dir.c_str());
    SLresult r = slCreateEngine(&g_engineObj, 0, nullptr, 0, nullptr, nullptr);
    if (r != SL_RESULT_SUCCESS) { LogE("DropMag: slCreateEngine gagal (%u)", (unsigned)r); return false; }
    (*g_engineObj)->Realize(g_engineObj, SL_BOOLEAN_FALSE);
    (*g_engineObj)->GetInterface(g_engineObj, SL_IID_ENGINE, &g_engine);
    (*g_engine)->CreateOutputMix(g_engine, &g_mixObj, 0, nullptr, nullptr);
    (*g_mixObj)->Realize(g_mixObj, SL_BOOLEAN_FALSE);

    for (int i = 0; i < 3; i++) {
        char p[512];
        snprintf(p, sizeof(p), "%s/audio/magdrop%d.mp3", g_dir.c_str(), i + 1);
        int fd = open(p, O_RDONLY);
        if (fd < 0) { LogE("DropMag: tidak bisa buka %s", p); continue; }
        LogI("DropMag: suara %s", p);

        Sound& s = g_sounds[g_soundCount];
        s.fd = fd;

        SLDataLocator_AndroidFD loc = { SL_DATALOCATOR_ANDROIDFD, fd, 0, SL_DATALOCATOR_ANDROIDFD_USE_FILE_SIZE };
        SLDataFormat_MIME mime = { SL_DATAFORMAT_MIME, nullptr, SL_CONTAINERTYPE_UNSPECIFIED };
        SLDataSource src = { &loc, &mime };
        SLDataLocator_OutputMix om = { SL_DATALOCATOR_OUTPUTMIX, g_mixObj };
        SLDataSink snk = { &om, nullptr };
        const SLInterfaceID ids[2] = { SL_IID_SEEK, SL_IID_VOLUME };
        const SLboolean req[2] = { SL_BOOLEAN_FALSE, SL_BOOLEAN_FALSE };

        SLresult pr = (*g_engine)->CreateAudioPlayer(g_engine, &s.playerObj, &src, &snk, 2, ids, req);
        if (pr != SL_RESULT_SUCCESS) { LogE("DropMag: CreateAudioPlayer gagal (%u) untuk %s", (unsigned)pr, p); close(fd); continue; }
        pr = (*s.playerObj)->Realize(s.playerObj, SL_BOOLEAN_FALSE);
        if (pr != SL_RESULT_SUCCESS) { LogE("DropMag: Realize gagal (%u) untuk %s", (unsigned)pr, p); (*s.playerObj)->Destroy(s.playerObj); close(fd); continue; }
        (*s.playerObj)->GetInterface(s.playerObj, SL_IID_PLAY, &s.play);
        if ((*s.playerObj)->GetInterface(s.playerObj, SL_IID_SEEK, &s.seek) != SL_RESULT_SUCCESS) s.seek = nullptr;
        if (cfg.volume < 1.0f) {
            SLVolumeItf vol = nullptr;
            if ((*s.playerObj)->GetInterface(s.playerObj, SL_IID_VOLUME, &vol) == SL_RESULT_SUCCESS && vol) {
                float v = cfg.volume < 0.01f ? 0.01f : cfg.volume;
                (*vol)->SetVolumeLevel(vol, (SLmillibel)(2000.0f * log10f(v)));
            }
        }
        (*s.play)->SetPlayState(s.play, SL_PLAYSTATE_PAUSED); // prefetch
        g_soundCount++;
    }
    LogI("DropMag: %d suara siap", g_soundCount);
    return g_soundCount > 0;
}

static void PlayDropSound() {
    if (!g_soundTried) { g_soundTried = true; InitSound(); }
    if (!g_soundCount) return;
    Sound& s = g_sounds[rand() % g_soundCount];
    (*s.play)->SetPlayState(s.play, SL_PLAYSTATE_STOPPED);
    if (s.seek) (*s.seek)->SetPosition(s.seek, 0, SL_SEEKMODE_FAST);
    SLresult r = (*s.play)->SetPlayState(s.play, SL_PLAYSTATE_PLAYING);
    LogI("DropMag: putar suara (hasil %u)", (unsigned)r);
}

// ---------------------------------------------------------------- symbol game
typedef void* (*FindPlayerPed_t)(int);
typedef void  (*GetBonePosition_t)(void* ped, V3* out, unsigned int bone, bool updateSkin);
typedef void* (*ObjectCreate_t)(int model, bool unk);
typedef void  (*WorldAddRemove_t)(void* entity);
typedef void  (*RequestModel_t)(int model, int flags);
typedef void  (*LoadAll_t)(bool);
typedef bool  (*Reload_t)(void* weapon, void* ped);
typedef void  (*TimerUpdate_t)();
typedef void  (*EntityUpdateRW_t)(void* entity);

static FindPlayerPed_t   FindPlayerPed;
static GetBonePosition_t GetBonePosition;
static ObjectCreate_t    ObjectCreate;
static WorldAddRemove_t  WorldAdd, WorldRemove;
static RequestModel_t    RequestModel;
static LoadAll_t         LoadAllRequestedModels;
static EntityUpdateRW_t  EntityUpdateRW;
static void**            ModelInfoPtrs;     // CModelInfo::ms_modelInfoPtrs
// RenderWare + TXD (untuk memuat DFF)
typedef void* (*RwStreamOpen_t)(int type, int access, const void* data);
typedef int   (*RwStreamFindChunk_t)(void* stream, unsigned type, unsigned* len, unsigned* ver);
typedef void* (*RpClumpStreamRead_t)(void* stream);
typedef int   (*RwStreamClose_t)(void* stream, void* data);
typedef void* (*RpClumpForAllAtomics_t)(void* clump, void* (*cb)(void*, void*), void* data);
typedef void* (*RpAtomicSetGeometry_t)(void* atomic, void* geom, unsigned flags);
typedef int   (*FindTxdSlot_t)(const char*);
typedef void  (*SetCurrentTxd_t)(int);
typedef void  (*TxdVoid_t)();
static RwStreamOpen_t         RwStreamOpen;
static RwStreamFindChunk_t    RwStreamFindChunk;
static RpClumpStreamRead_t    RpClumpStreamRead;
static RwStreamClose_t        RwStreamClose;
static RpClumpForAllAtomics_t RpClumpForAllAtomics;
static RpAtomicSetGeometry_t  RpAtomicSetGeometry;
static FindTxdSlot_t          FindTxdSlot;
static SetCurrentTxd_t        SetCurrentTxd;
static TxdVoid_t              PushCurrentTxd, PopCurrentTxd;
static Reload_t          Reload_orig;
static TimerUpdate_t     TimerUpdate_orig;

// Layout CPlaceable/CEntity. Pointer 8 byte di 64-bit menggeser offset.
//   32-bit: vtable(4) pos(+4) m_pMatrix(+0x14) m_pRwObject(+0x18) m_nFlags(+0x1C)
//   64-bit: vtable(8) pos(+8) m_pMatrix(+0x18) m_pRwObject(+0x20) m_nFlags(+0x28)
#if defined(__LP64__)
static const int OFF_PLACEMENT_POS = 0x08;
static const int OFF_MATRIX_PTR    = 0x18;
static const int OFF_ENT_FLAGS     = 0x28;   // bit0 = bUsesCollision
static const int OFF_ENT_RWOBJECT  = 0x20;   // CEntity::m_pRwObject
static const int OFF_ATOMIC_GEOM   = 0x30;   // RpAtomic::geometry (object+lFrame+sync+repEntry)
#else
static const int OFF_PLACEMENT_POS = 0x04;
static const int OFF_MATRIX_PTR    = 0x14;
static const int OFF_ENT_FLAGS     = 0x1C;
static const int OFF_ENT_RWOBJECT  = 0x18;
static const int OFF_ATOMIC_GEOM   = 0x18;
#endif
// CMatrix: right(0x00) fwd(0x10) up(0x20) pos(0x30), sama di 32/64-bit
static const int MAT_RIGHT = 0x00, MAT_FWD = 0x10, MAT_UP = 0x20, MAT_POS = 0x30;

static V3 GetPos(void* e) {
    char* p = (char*)e;
    char* m = *(char**)(p + OFF_MATRIX_PTR);
    V3* v = m ? (V3*)(m + MAT_POS) : (V3*)(p + OFF_PLACEMENT_POS);
    return *v;
}
static void SetPosRot(void* e, const V3& pos, float yaw) {
    char* p = (char*)e;
    char* m = *(char**)(p + OFF_MATRIX_PTR);
    if (!m) { *(V3*)(p + OFF_PLACEMENT_POS) = pos; return; }
    float c = cosf(yaw), s = sinf(yaw);
    *(V3*)(m + MAT_RIGHT) = { c, s, 0 };
    *(V3*)(m + MAT_FWD)   = { -s, c, 0 };
    *(V3*)(m + MAT_UP)    = { 0, 0, 1 };
    *(V3*)(m + MAT_POS)   = pos;
}

// ---------------------------------------------------------------- logika
struct Mag { void* obj; V3 pos; float yaw, vz, groundZ; bool landed; double dieAt; };
static std::vector<Mag> g_mags;
static double g_prevTime = 0, g_lastSpawn = -10;
static bool   g_pending = false;
static double g_spawnAt = 0;
static int    g_pendingType = 0;

static double Now() {
    timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec + ts.tv_nsec * 1e-9;
}

static void DestroyEntity(void* e) {   // untuk objek yang belum di-Add ke dunia
    void** vt = *(void***)e;
    ((void(*)(void*))vt[1])(e);
}
static void DeleteEntity(void* e) {
    WorldRemove(e);
    // virtual deleting destructor = vtable[1] (Itanium ABI)
    void** vt = *(void***)e;
    ((void(*)(void*))vt[1])(e);
}

// ---- pemuat DFF (nama file apa adanya, tanpa rename)
static const char* MagFile(int t) {
    switch (t) {
    case W_PISTOL:   return "pistol_mag.dff";
    case W_SILENCED: return "spistol_mag.dff";
    case W_DEAGLE:   return "deagle_mag.dff";
    case W_UZI:      return "uzi_mag.dff";
    case W_MP5:      return "mp5_mag.dff";
    case W_AK47:     return "ak_mag.dff";
    case W_M4:       return "m4_mag.dff";
    case W_TEC9:     return "tec_mag.dff";
    }
    return nullptr;
}
static bool IsMagWeapon(int t) { return MagFile(t) != nullptr; }

static void* g_geom[48];
static char  g_geomState[48];   // 0 = belum dicoba, 1 = ok, 2 = gagal

static void* FirstGeomCB(void* atomic, void* data) {
    void** out = (void**)data;
    if (!*out) *out = *(void**)((char*)atomic + OFF_ATOMIC_GEOM);
    return atomic;
}

static void* LoadGeometry(int type) {
    if (g_geomState[type]) return g_geomState[type] == 1 ? g_geom[type] : nullptr;
    g_geomState[type] = 2;
    const char* name = MagFile(type);
    if (!name || !RwStreamOpen || !RwStreamFindChunk || !RpClumpStreamRead || !RwStreamClose ||
        !RpClumpForAllAtomics || !RpAtomicSetGeometry) return nullptr;

    std::string path = g_dir + "/models/" + name;
    FILE* f = fopen(path.c_str(), "rb");
    if (!f) { LogE("DropMag: tidak bisa buka %s", path.c_str()); return nullptr; }
    fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET);
    std::vector<unsigned char> buf(n);
    fread(buf.data(), 1, n, f);
    fclose(f);

    // Tekstur diambil dari TXD senjata: nama tekstur di DFF dipakai sebagai nama TXD
    int slot = -1;
    static const char* txds[] = { "ak47", "tec9", "mp5lng", "micro_uzi", "colt45", "silenced", "desert_eagle" };
    if (FindTxdSlot && SetCurrentTxd && PushCurrentTxd && PopCurrentTxd) {
        for (const char* t : txds) {
            if (memmem(buf.data(), buf.size(), t, strlen(t))) {
                slot = FindTxdSlot(t);
                if (slot >= 0) break;
            }
        }
    }
    if (slot >= 0) {
        RequestModel(slot + 20000, 2 /*GAME_REQUIRED*/);
        LoadAllRequestedModels(false);
        PushCurrentTxd();
        SetCurrentTxd(slot);
    }

    struct { unsigned char* start; unsigned length; } mem = { buf.data(), (unsigned)buf.size() };
    void* geom = nullptr;
    void* stream = RwStreamOpen(3 /*rwSTREAMMEMORY*/, 1 /*rwSTREAMREAD*/, &mem);
    if (stream) {
        if (RwStreamFindChunk(stream, 0x10 /*rwID_CLUMP*/, nullptr, nullptr)) {
            void* clump = RpClumpStreamRead(stream);   // clump sengaja tidak dihapus
            if (clump) RpClumpForAllAtomics(clump, FirstGeomCB, &geom);
        }
        RwStreamClose(stream, nullptr);
    }
    if (slot >= 0) PopCurrentTxd();

    if (!geom) { LogE("DropMag: gagal membaca %s", name); return nullptr; }
    g_geom[type] = geom;
    g_geomState[type] = 1;
    LogI("DropMag: %s dimuat", name);
    return geom;
}

static bool SpawnMagImpl(void* ped, int type) {
    int model = cfg.modelFor[type] > 0 ? cfg.modelFor[type] : cfg.donorModel;
    void* geom = nullptr;
    if (cfg.modelFor[type] <= 0) {
        if (!cfg.useDff) return false;
        geom = LoadGeometry(type);
        if (!geom) return false;
    }
    if (!ModelInfoPtrs || model <= 0 || model >= 20000 || !ModelInfoPtrs[model]) {
        LogE("DropMag: model id %d tidak valid / belum terdaftar", model);
        return false;
    }
    RequestModel(model, 2 /*GAME_REQUIRED*/);
    LoadAllRequestedModels(false);

    while ((int)g_mags.size() >= cfg.maxMags && !g_mags.empty()) {
        DeleteEntity(g_mags.front().obj);
        g_mags.erase(g_mags.begin());
    }

    V3 pos = GetPos(ped);
    pos.z += 0.3f;
    if (GetBonePosition) {
        V3 b;
        GetBonePosition(ped, &b, 32 /*BONE_L_HAND*/, false);
        V3 pp = GetPos(ped);
        float dx = b.x - pp.x, dy = b.y - pp.y, dz = b.z - pp.z;
        if (dx*dx + dy*dy + dz*dz < 9.0f) pos = b;
    }

    void* obj = ObjectCreate(model, false);
    if (!obj) return false;
    if (geom) {
        void* rw = *(void**)((char*)obj + OFF_ENT_RWOBJECT);
        if (!rw || *(unsigned char*)rw != 1 /*rpATOMIC*/) {
            LogE("DropMag: model donor %d bukan atomic, coba DonorModel lain", model);
            DestroyEntity(obj);   // belum masuk dunia
            return false;
        }
        RpAtomicSetGeometry(rw, geom, 0);
    }
    *(unsigned char*)((char*)obj + OFF_ENT_FLAGS) &= ~1; // tanpa collision, gerak diatur plugin

    Mag m;
    m.obj = obj; m.pos = pos; m.vz = 0;
    m.yaw = (rand() % 628) / 100.0f;
    m.groundZ = GetPos(ped).z - 1.0f + cfg.groundOffset; // kira-kira tinggi tanah di bawah kaki ped
    m.landed = false;
    m.dieAt = Now() + cfg.lifetimeMs / 1000.0;
    SetPosRot(obj, pos, m.yaw);
    WorldAdd(obj);
    if (EntityUpdateRW) EntityUpdateRW(obj);
    g_mags.push_back(m);
    LogI("DropMag: magazen dibuat (senjata %d, model %d, dari %s)", type, model, geom ? "DFF" : "ID model");
    return true;
}

static double g_fallbackSoundAt = 0;
static void SpawnMag(void* ped, int type) {
    if (!SpawnMagImpl(ped, type)) {
        // magazen gagal dibuat -> suara tetap diputar supaya fiturnya terasa
        LogE("DropMag: magazen gagal dibuat, hanya suara yang diputar");
        g_fallbackSoundAt = Now() + 0.6;
    }
}

static void UpdateMags(float dt) {
    double now = Now();
    for (size_t i = 0; i < g_mags.size();) {
        Mag& m = g_mags[i];
        if (now >= m.dieAt) { DeleteEntity(m.obj); g_mags.erase(g_mags.begin() + i); continue; }
        if (!m.landed) {
            m.vz -= cfg.gravity * dt;
            m.pos.z += m.vz * dt;
            bool land = m.pos.z <= m.groundZ;
            if (land) m.pos.z = m.groundZ;
            WorldRemove(m.obj);
            SetPosRot(m.obj, m.pos, m.yaw);
            WorldAdd(m.obj);
            if (EntityUpdateRW) EntityUpdateRW(m.obj);
            if (land) { m.landed = true; PlayDropSound(); }
        }
        ++i;
    }
}

// ---------------------------------------------------------------- hook
// CWeapon: +0 tipe senjata, +4 state (2 = RELOADING)
static bool Reload_hook(void* weapon, void* ped) {
    int stateBefore = *(int*)((char*)weapon + 4);
    bool r = Reload_orig(weapon, ped);
    int stateAfter = *(int*)((char*)weapon + 4);
    int type = *(int*)weapon;

    if (stateBefore != 2 && stateAfter == 2 &&
        FindPlayerPed && ped == FindPlayerPed(-1) &&
        type >= 0 && type < 48 && IsMagWeapon(type) &&
        (cfg.modelFor[type] > 0 || cfg.useDff)) {
        double now = Now();
        if (now - g_lastSpawn > 1.0) {
            g_lastSpawn = now;
            g_pending = true;
            g_pendingType = type;
            LogI("DropMag: reload terdeteksi (senjata %d)", type);
            g_spawnAt = now + cfg.spawnDelayMs / 1000.0;
        }
    }
    return r;
}

static void Tick_hook() {
    TimerUpdate_orig();
    double now = Now();
    float dt = g_prevTime > 0 ? (float)(now - g_prevTime) : 0.016f;
    if (dt > 0.1f) dt = 0.1f;
    g_prevTime = now;

    if (g_pending && now >= g_spawnAt) {
        g_pending = false;
        void* ped = FindPlayerPed(-1);
        if (ped) SpawnMag(ped, g_pendingType);
    }
    if (g_fallbackSoundAt > 0 && now >= g_fallbackSoundAt) { g_fallbackSoundAt = 0; PlayDropSound(); }
    UpdateMags(dt);
}

// ---------------------------------------------------------------- entry
extern "C" void OnModLoad() {
    logger->SetTag("DropMag");
    g_dir = FindDir();
    StartLogFile(g_dir);
    LoadConfig();
    LogI("DropMag: pengaturan UseDff=%d DonorModel=%d SpawnDelayMs=%d LifetimeMs=%d", cfg.useDff, cfg.donorModel, cfg.spawnDelayMs, cfg.lifetimeMs);

    void* h = aml->GetLibHandle("libGTASA.so");
    if (!h) { LogE("DropMag: libGTASA.so tidak ketemu"); return; }
    #define SYM(var, name) var = (decltype(var))aml->GetSym(h, name); \
        if (!var) LogE("DropMag: symbol hilang: %s", name)
    SYM(FindPlayerPed,          "_Z13FindPlayerPedi");
    SYM(GetBonePosition,        "_ZN4CPed15GetBonePositionER5RwV3djb");
    SYM(ObjectCreate,           "_ZN7CObject6CreateEib");
    SYM(WorldAdd,               "_ZN6CWorld3AddEP7CEntity");
    SYM(WorldRemove,            "_ZN6CWorld6RemoveEP7CEntity");
    SYM(RequestModel,           "_ZN10CStreaming12RequestModelEii");
    SYM(LoadAllRequestedModels, "_ZN10CStreaming22LoadAllRequestedModelsEb");
    SYM(EntityUpdateRW,         "_ZN7CEntity8UpdateRWEv");
    SYM(ModelInfoPtrs,          "_ZN10CModelInfo16ms_modelInfoPtrsE");
    SYM(RwStreamOpen,         "RwStreamOpen");
    SYM(RwStreamFindChunk,    "RwStreamFindChunk");
    SYM(RpClumpStreamRead,    "RpClumpStreamRead");
    SYM(RwStreamClose,        "RwStreamClose");
    SYM(RpClumpForAllAtomics, "RpClumpForAllAtomics");
    SYM(RpAtomicSetGeometry,  "RpAtomicSetGeometry");
    SYM(FindTxdSlot,          "_ZN9CTxdStore11FindTxdSlotEPKc");
    SYM(SetCurrentTxd,        "_ZN9CTxdStore14SetCurrentTxdEi");
    SYM(PushCurrentTxd,       "_ZN9CTxdStore14PushCurrentTxdEv");
    SYM(PopCurrentTxd,        "_ZN9CTxdStore13PopCurrentTxdEv");
    void* reloadFn = (void*)aml->GetSym(h, "_ZN7CWeapon6ReloadEP4CPed");
    void* tickFn   = (void*)aml->GetSym(h, "_ZN6CTimer6UpdateEv");

    if (!FindPlayerPed || !ObjectCreate || !WorldAdd || !WorldRemove || !RequestModel ||
        !LoadAllRequestedModels || !ModelInfoPtrs || !reloadFn || !tickFn) {
        LogE("DropMag: symbol penting hilang, plugin dinonaktifkan");
        return;
    }

    aml->Hook(reloadFn, (void*)Reload_hook, (void**)&Reload_orig);
    aml->Hook(tickFn,   (void*)Tick_hook,   (void**)&TimerUpdate_orig);
    LogI("DropMag aktif");
}
